<?php

use App\Http\Controllers\Api\LapkeuController;
use App\Http\Controllers\Api\MasjidController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\DataZiswafController;
use App\Http\Controllers\Api\DonationController;
use App\Http\Controllers\Api\QurbanController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/masjid', [MasjidController::class, 'masjid']);
Route::get('/lapkeu/{id}', [LapkeuController::class, 'lapkeu']);
Route::get('/kas/{id}', [LapkeuController::class, 'kas']);
Route::get('/dataziswaf', [DataZiswafController::class, 'DataZiswaf']);
Route::post('/login', [AuthController::class, 'login']);
Route::get('/dataMasjid', [MasjidController::class, 'dataMasjid']);
Route::get('/emas', [DataZiswafController::class, 'emas']);
Route::post('/donation', [DonationController::class, 'pay']);
Route::post('/formDonation', [DonationController::class, 'formDonation']);
Route::post('/payment/notification/finish', [DonationController::class, 'finishPayment']);
Route::post('/qurban', [QurbanController::class, 'dataQurban']);
Route::post('/riwayat', [DonationController::class, 'riwayat']);
