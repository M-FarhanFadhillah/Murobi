<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Masjid;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        // Cek apakah user ada
        $user = User::where('email', strtolower($request->email))->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            // Jika login gagal
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid credentials',
            ], 401);
        }

        // $rememberToken = Str::random(60);
        // $hashedRememberToken = Hash::make($rememberToken);
        // $user->update(['remember_token' => $hashedRememberToken]);

        return response()->json([
            'status' => 'success',
            'message' => 'Login successful',
            // 'token' => $rememberToken,
        ]);
    }
}
