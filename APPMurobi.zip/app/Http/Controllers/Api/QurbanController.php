<?php

namespace App\Http\Controllers\Api;

use App\Models\DataZiswaf;
use App\Http\Controllers\Controller;
use App\Models\Masjid;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class QurbanController extends Controller
{
    public function dataQurban(Request $request)
    {
        $request->validate([
            'token' => 'required',
        ]);

        $token = $request->input('token');

        $user = User::all()->filter(function ($user) use ($token) {
            return Hash::check($token, $user->remember_token);
        })->first();

        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid token'
            ], 401);
        }

        $masjids = Masjid::all();

        foreach ($masjids as $masjid) {
            $id = $masjid->id;
            $nama = $masjid->masjid_name;

            $dataQurban = DataZiswaf::where('masjid_id', $id)
                ->where('jenis_ziswaf_id', 5)
                ->where('status', 'success')
                ->whereYear('created_at', Carbon::now()->year)
                ->select('jenis_barang', DB::raw('SUM(jumlah_barang) as total_jumlah'))
                ->groupBy('jenis_barang')
                ->get();

            $result = [
                'masjid_id' => $id,
                'masjid_name'=> $nama,
                'sapi' => 0,
                'kambing' => 0,
                'sapi_user' => 0,
                'kambing_user' => 0,
            ];

            foreach ($dataQurban as $data) {
                if ($data->jenis_barang == 'sapi') {
                    $result['sapi'] = (int)$data->total_jumlah;
                } elseif ($data->jenis_barang == 'kambing') {
                    $result['kambing'] = (int)$data->total_jumlah;
                }
            }

            $userQurban = DataZiswaf::where('masjid_id', $id)
                ->where('jenis_ziswaf_id', 5)
                ->where('status', 'success')
                ->where('user_id', $user->id)
                ->whereYear('created_at', Carbon::now()->year)
                ->select('jenis_barang', DB::raw('SUM(jumlah_barang) as total_jumlah'))
                ->groupBy('jenis_barang')
                ->get();

            foreach ($userQurban as $data) {
                if ($data->jenis_barang == 'sapi') {
                    $result['sapi_user'] = (int)$data->total_jumlah;
                } elseif ($data->jenis_barang == 'kambing') {
                    $result['kambing_user'] = (int)$data->total_jumlah;
                }
            }

            $results[] = $result;
        }

        return response()->json($results);
    }
}
