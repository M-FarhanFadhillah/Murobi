<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DataZiswaf;
use App\Models\Emas;
use App\Models\User;
use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\DomCrawler\Crawler;

class DataZiswafController extends Controller
{
    public function DataZiswaf(Request $request)
    {
        $email = $request->input('email');
        $id = $request->input('id');
        $jenis = $request->input('jenis');

        if (!$email || !$id || !$jenis) {
            return response()->json(['error' => 'Missing parameters'], 400);
        }

        try {
            $user = User::where('email', $email)->first();

            if (!$user) {
                return response()->json(['error' => 'User not found'], 404);
            }

            $data = DataZiswaf::where('masjid_id', $id)
                ->where('user_id', $user->id)
                ->where('jenis_ziswaf_id', $jenis)
                ->get();

            if ($data->isEmpty()) {
                return response()->json(['error' => 'No data found'], 404);
            }
            return response()->json($data);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Resource not found'], 404);
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return response()->json(['error' => 'Internal Server Error'], 500);
        }
    }

    public function emas()
    {
        $emas = Emas::first();

        $now = Carbon::now();
        $nowJkt = $now->addHours(7);
        $yesterday = Carbon::yesterday()->addHours(8)->addMinutes(30);
        $today = Carbon::today()->addHours(8)->addMinutes(30);

        // Check if update is needed
        $needsUpdate = !$emas || ($nowJkt > $today && !$emas->isupdatedtoday) ||
            !($emas->updated_at < $today && $emas->updated_at > $yesterday);

        if ($needsUpdate) {
            $client = new Client();
            $url = 'https://www.logammulia.com/id/harga-emas-hari-ini';

            $response = $client->request('GET', $url);
            $html = $response->getBody()->getContents();

            $crawler = new Crawler($html);

            // Extract the relevant data
            $data = $crawler->filter('tr')->each(function (Crawler $node) {
                $columns = $node->filter('td')->each(function (Crawler $columnNode) {
                    return trim($columnNode->text());
                });

                if (count($columns) > 1) {
                    return [
                        'weight' => $columns[0],
                        'price1' => $columns[1],
                        'price2' => $columns[2],
                    ];
                }

                return null;
            });

            // Filter the data to get the price for 1 gram
            $filteredData = array_filter($data, function ($item) {
                return isset($item['weight']) && $item['weight'] === "1 gr";
            });

            $hargaEmas = 0;
            if (!empty($filteredData)) {
                $getHargaEmas = array_values($filteredData)[0]['price1'];
                $hargaEmas = (int) str_replace(',', '', $getHargaEmas);
            }

            // Update or create the record
            $isUpdatedToday = $now > $today;
            if ($emas) {
                $emas->harga = $hargaEmas;
                $emas->updated_at = $now;
                $emas->isupdatedtoday = $isUpdatedToday;
                $emas->save();
            } else {
                Emas::create([
                    'harga' => $hargaEmas,
                    'created_at' => $now,
                    'updated_at' => $now,
                    'isupdatedtoday' => $isUpdatedToday,
                ]);
            }
        } else {
            $hargaEmas = $emas->harga;
        }

        return $hargaEmas;
    }
}
