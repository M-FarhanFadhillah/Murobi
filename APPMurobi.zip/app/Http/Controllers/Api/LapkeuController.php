<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DataZiswaf;
use App\Models\Lapkeu;
use App\Models\Masjid;
use Carbon\Carbon;
use Illuminate\Http\Request;

class LapkeuController extends Controller
{
    public function lapkeu($id)
    {
        $lapkeu = Lapkeu::where('masjid_id', $id)
            ->where('jenis_ziswaf_id', 3)
            ->orderBy('tanggal', 'desc')
            ->get();
        $lapkeu->transform(function ($item) {
            $item->arus = 1;
            return $item;
        });

        $masjid = Masjid::find($id);
        $saldoAwal = $masjid->saldo_awal;

        $totalZakFit = DataZiswaf::where('masjid_id', $id)
            ->where('jenis_ziswaf_id', 2)
            ->where('status', 'success')
            ->whereYear('created_at', Carbon::now()->year)
            ->sum('jumlah_uang') ?? 0;

        $totalZakMal = DataZiswaf::where('masjid_id', $id)
            ->where('jenis_ziswaf_id', 1)
            ->where('status', 'success')
            ->whereYear('created_at', Carbon::now()->year)
            ->sum('jumlah_uang') ?? 0;

        $totWakaf = DataZiswaf::where('masjid_id', $id)
            ->where('jenis_ziswaf_id', 4)
            ->where('status', 'success')
            ->sum('jumlah_uang') ?? 0;

        $relWakaf = Lapkeu::where('masjid_id', $id)
            ->where('jenis_ziswaf_id', 4)
            ->sum('jumlah') ?? 0;

        $totalPengeluaran = Lapkeu::where('masjid_id', $id)->sum('jumlah') ?? 0;
        $totalPemasukan = DataZiswaf::where('masjid_id', $id)
            ->where('jenis_ziswaf_id', 3)
            ->where('status', 'success')
            ->sum('jumlah_uang') ?? 0;

        $pengeluaranBulanNow = Lapkeu::where('masjid_id', $id)
            ->whereMonth('tanggal', date('m'))
            ->whereYear('tanggal', date('Y'))
            ->sum('jumlah') ?? 0;

        $pemasukanBulanNow = DataZiswaf::where('masjid_id', $id)
            ->whereMonth('tanggal', date('m'))
            ->whereYear('tanggal', date('Y'))
            ->where('jenis_ziswaf_id', 3)
            ->where('status', 'success')
            ->sum('jumlah_uang') ?? 0;

        $saldoAkhir = $saldoAwal - $totalPengeluaran + $totalPemasukan;

        $dataWakaf = DataZiswaf::where('masjid_id', $id)
            ->where('jenis_ziswaf_id', 4)
            ->where('status', 'success')
            ->orderBy('tanggal', 'desc')
            ->get();

        $dataWakaf->transform(function ($item) {
            $item->sumbangan = $item->nama_barang ? $item->jumlah_uang . ' ' . $item->nama_barang : $item->jumlah_uang;
            return $item;
        });

        return response()->json([
            "saldoAkhir" => $saldoAkhir,
            "inSaldoNow" => $pemasukanBulanNow,
            "totZakFit" => $totalZakFit,
            "totZakMal" => $totalZakMal,
            'lapkeu' => $lapkeu,
            "dataWakaf" => $dataWakaf,
            'totWakaf' => $totWakaf,
            'relWakaf' => $relWakaf
        ]);
    }
}
