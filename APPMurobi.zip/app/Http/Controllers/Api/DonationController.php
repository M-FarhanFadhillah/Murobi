<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DataZiswaf;
use Midtrans\Snap;
use App\Models\Masjid;
use App\Models\Qurban;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DonationController extends Controller
{
    protected $response = [];

    public function __construct()
    {
        \Midtrans\Config::$serverKey    = config('services.midtrans.serverKey');
        \Midtrans\Config::$isProduction = config('services.midtrans.isProduction');
        \Midtrans\Config::$isSanitized  = config('services.midtrans.isSanitized');
        \Midtrans\Config::$is3ds        = config('services.midtrans.is3ds');
    }

    public function formDonation(Request $request)
    {
        $request->validate([
            'token' => 'required'
        ]);

        // Retrieve the token from the request
        $token = $request->input('token');

        // Find the user with the given token by checking the hash
        $user = User::all()->filter(function ($user) use ($token) {
            return Hash::check($token, $user->remember_token);
        })->first();

        // Check if the user is found
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid token'
            ], 401);
        }

        $emasCtrl = new DataZiswafController();
        $emas = $emasCtrl->emas();

        $dataQurban = Qurban::with('masjid')->get();
        $groupedQurban = $dataQurban->groupBy('masjid_id');
        $qurbanData = $groupedQurban->map(function ($items, $key) {
            $masjid = $items->first()->masjid;

            $qurbanList = $items->map(function ($item) {
                return [
                    'id_qurban' => $item->id,
                    'nama_qurban' => $item->nama_qurban,
                    'harga' => $item->harga
                ];
            });

            return [
                'masjid_name' => $masjid->masjid_name,
                'masjid_id' => $key,
                'qurban' => $qurbanList
            ];
        })->values();

        $userData = [
            'user_id' => $user->id,
            'user_name' => $user->name,
            'user_email' => $user->email,
            'user_phone' => $user->no_hp,
        ];

        return response()->json([
            'dataUser' => $userData,
            'dataQurban' => $qurbanData,
            'emas' => $emas
        ]);
    }

    public function pay(Request $request)
    {   
        $request->validate([
            'token' => 'required'
        ]);

        // Retrieve the token from the request
        $token = $request->input('token');

        // Find the user with the given token by checking the hash
        $user = User::all()->filter(function ($user) use ($token) {
            return Hash::check($token, $user->remember_token);
        })->first();

        // Check if the user is found
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid token'
            ], 401);
        }
        
        DB::transaction(function () use ($request) {
            $validateData = $request->validate([
                'order_id' => 'required|string',
                'user_id' => 'required|integer',
                'masjid_id' => 'required|integer',
                'jenis_ziswaf_id' => 'required|integer',
                'first_name' => 'required|string',
                'email' => 'required|email',
                'jumlah_uang' => 'required|numeric',
                'note' => 'nullable|string',
                'nama_barang' => 'nullable|string',
                'jenis_barang' => 'nullable|string',
                'jumlah_barang' => 'nullable|integer',
                'nama_ziswaf' => 'nullable|array',
            ]);
            
            $harga = $validateData['jumlah_uang'];
            
            if ($request->input('jenis_ziswaf_id') == 5) {
                $hargaQurban = DB::table('qurban')
                    ->where('masjid_id', $validateData['masjid_id'])
                    ->where('nama_qurban', $validateData['jenis_barang'])
                    ->value('harga');
                    
                $harga = $hargaQurban * $validateData['jumlah_barang'];
            }

            $jenis = DB::table('jenis_ziswafs')
                ->where('id', $validateData['jenis_ziswaf_id'])
                ->value('jenis');

            $masjidName = DB::table('masjids')
                ->where('id', $validateData['masjid_id'])
                ->value('masjid_name');

            $donation = DataZiswaf::create([
                'order_id' => $validateData['order_id'],
                'user_id' => $validateData['user_id'],
                'masjid_id' => $validateData['masjid_id'],
                'jenis_ziswaf_id' => $validateData['jenis_ziswaf_id'],
                'tanggal' => Carbon::now(),
                'jumlah_uang' => $harga,
                'nama_barang' => $validateData['nama_barang'],
                'jenis_barang' => $validateData['jenis_barang'],
                'jumlah_barang' => $validateData['jumlah_barang'],
                'note' => $validateData['note'],
                'nama_ziswaf' => json_encode($validateData['nama_ziswaf']),
            ]);
            
            $payload = [
                'transaction_details' => [
                    'order_id' => $donation->order_id,
                    'gross_amount' => $donation->jumlah_uang,
                ],
                'customer_details' => [
                    'first_name' => 'Jemaah',
                    'email' => $validateData['email'],
                ],
                'item_details' => [
                    [
                        'id' => $donation->id,
                        'price' => $donation->jumlah_uang,
                        'quantity' => 1,
                        'name' => 'Donation to ' . config('app.name'),
                        'brand' => 'Donation',
                        'category' => $jenis,
                        'merchant_name' => $masjidName,
                    ],
                ],
            ];

            $snapResponse = Snap::createTransaction($payload);

            // $donation->transaction_id = $snapResponse->transaction_id;
            $donation->snap_token = $snapResponse->token;
            $donation->save();

            $this->response['redUrl'] = $snapResponse->redirect_url;
        });
        return response()->json([
            'snapUrl' => $this->response['redUrl']
        ]);
    }

    public function finishPayment(Request $request)
    {
        try {
            $notification_body = json_decode($request->getContent(), true);
            $invoice = $notification_body['order_id'];
            $transaction_id = $notification_body['transaction_id'];
            $status_code = $notification_body['status_code'];
            $order = DataZiswaf::where('order_id', $invoice)->first();
            // $order->transaction_id = $transaction_id;
            if (!$order)
                return ['code' => 0, 'messgae' => 'Terjadi kesalahan | Pembayaran tidak valid'];
            switch ($status_code) {
                case '200':
                    $order->status = "success";
                    break;
                case '201':
                    $order->status = "pending";
                    break;
                case '202':
                    $order->status = "cancel";
                    break;
            }
            $order->save();
            return response('Ok', 200)->header('Content-Type', 'text/plain');
        } catch (\Exception $e) {
            return response('Error', 404)->header('Content-Type', 'text/plain');
        }
    }
    
    public function riwayat(Request $request){
        $request->validate([
            'token' => 'required'
        ]);
        
        // Retrieve the token from the request
        $token = $request->input('token');

        // Find the user with the given token by checking the hash
        $user = User::all()->filter(function ($user) use ($token) {
            return Hash::check($token, $user->remember_token);
        })->first();

        // Check if the user is found
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid token'
            ], 401);
        }

        try{
        $dataZiswaf = DataZiswaf::with('jenis_ziswaf')
            ->where('user_id', $user->id)
            ->orderBy('tanggal', 'desc')
            ->get();

        $formattedData = $dataZiswaf->map(function ($item) {
            $jenis = $item->jenis_ziswaf->jenis;
            if ($item->jenis_ziswaf_id == 5){
                $jenis = $item->jumlah_barang . ' ' . $item->jenis_barang;
            }
            return [
                'jumlah' => $item->jumlah_uang,
                'tanggal' => $item->tanggal,
                'jenisZakat' => $jenis,
                'status' => $item->status,
                'snap' => $item->snap_token,
                'namaBarang' => $item->namaBarang,
            ];
        });
        } catch (\Exception $e) {
            return response($e)->header('Content-Type', 'text/plain');
        }

        return response()->json($formattedData);
    }
}
