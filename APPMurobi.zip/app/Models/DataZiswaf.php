<?php

namespace App\Models; 

use App\Models\JenisZiswaf;
use App\Models\Masjid;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DataZiswaf extends Model
{
    use HasFactory;
    protected $guarded = ['id'];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function masjid()
    {
        return $this->belongsTo(Masjid::class, 'masjid_id');
    }

    public function jenis_ziswaf()
    {
        return $this->belongsTo(JenisZiswaf::class, 'jenis_ziswaf_id');
    }
}
