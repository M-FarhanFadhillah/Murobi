<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Qurban extends Model
{
    use HasFactory;
    protected $table = 'qurban';
    protected $guarded = ['id'];
    public function masjid()
    {
        return $this->belongsTo(Masjid::class, 'masjid_id');
    }
}
