<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Masjid extends Model
{
    use HasFactory;
    protected $guarded = [
        'id'
    ];
    public function lap_keu(){
        return $this->hasMany(Lapkeu::class, 'masjid_id');
    }
    public function data_ziswaf(){
        return $this->hasMany(DataZiswaf::class, 'masjid_id');
    }
}
