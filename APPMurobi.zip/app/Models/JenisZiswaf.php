<?php

namespace App\Models;

use App\Models\DataZiswaf;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JenisZiswaf extends Model
{
    use HasFactory;
    protected $guarded = [
        'id'
    ];
    public function dataZiswaf()
    {
        return $this->hasMany(DataZiswaf::class, 'jenis_ziswaf_id');
    }
}
