<?php

namespace Database\Seeders;

use App\Models\JenisZiswaf;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class JenisZiswafSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        JenisZiswaf::create([
            'jenis' => 'zakat-Mal',
        ]);
        
        JenisZiswaf::create([
            'jenis' => 'zakat-Fitrah',
        ]);

        JenisZiswaf::create([
            'jenis' => 'Infaq/Sedekah',
        ]);

        JenisZiswaf::create([
            'jenis' => 'Wakaf',
        ]);

        JenisZiswaf::create([
            'jenis' => 'Qurban',
        ]);
    }
}
