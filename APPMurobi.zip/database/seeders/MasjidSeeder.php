<?php

namespace Database\Seeders;

use App\Models\Masjid;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class MasjidSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Masjid::create([
            'masjid_name' => 'Masjid Raya',
            'masjid_pict' => 'masjid_raya.jpg',
            'alamat' => 'Jl. Raya No. 1',
            'saldo_awal' => 10000000.00,
        ]);

        Masjid::create([
            'masjid_name' => 'Masjid Al-Hikmah',
            'masjid_pict' => 'masjid_al_hikmah.jpg',
            'alamat' => 'Jl. Hikmah No. 2',
            'saldo_awal' => 5000000.00,
        ]);

        Masjid::create([
            'masjid_name' => 'Masjid Al-Falah',
            'masjid_pict' => 'masjid_al_falah.jpg',
            'alamat' => 'Jl. Falah No. 3',
            'saldo_awal' => 7500000.00,
        ]);
    }
}
