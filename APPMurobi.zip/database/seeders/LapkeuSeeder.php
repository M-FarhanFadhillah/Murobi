<?php

namespace Database\Seeders;

use App\Models\Lapkeu;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class LapkeuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Lapkeu::create([
            'masjid_id' => 1, // Pastikan masjid_id ini sesuai dengan data masjid yang ada
            'tanggal' => '2023-05-30',
            'jumlah' => 1500000.00,
            'note' => 'Pembelian alat kebersihan',
        ]);

        Lapkeu::create([
            'masjid_id' => 1, // Pastikan masjid_id ini sesuai dengan data masjid yang ada
            'tanggal' => '2023-04-30',
            'jumlah' => 200000.00,
            'note' => 'Acara Hajatan',
        ]);

        Lapkeu::create([
            'masjid_id' => 1, // Pastikan masjid_id ini sesuai dengan data masjid yang ada
            'tanggal' => '2023-03-30',
            'jumlah' => 300000.00,
            'note' => 'Listrik',
        ]);

        Lapkeu::create([
            'masjid_id' => 1, // Pastikan masjid_id ini sesuai dengan data masjid yang ada
            'tanggal' => '2023-02-28',
            'jumlah' => 75000.00,
            'note' => 'Santunan',
        ]);

        Lapkeu::create([
            'masjid_id' => 1, // Pastikan masjid_id ini sesuai dengan data masjid yang ada
            'tanggal' => '2023-01-30',
            'jumlah' => 50000.00,
            'note' => 'Pengajian',
        ]);

        Lapkeu::create([
            'masjid_id' => 1, // Pastikan masjid_id ini sesuai dengan data masjid yang ada
            'tanggal' => '2023-03-18',
            'jumlah' => 500000.00,
            'note' => 'Perbaikan',
        ]);

        Lapkeu::create([
            'masjid_id' => 1, // Pastikan masjid_id ini sesuai dengan data masjid yang ada
            'tanggal' => '2023-05-05',
            'jumlah' => 15000.00,
            'note' => 'Kultum',
        ]);

        Lapkeu::create([
            'masjid_id' => 1, // Pastikan masjid_id ini sesuai dengan data masjid yang ada
            'tanggal' => '2023-05-13',
            'jumlah' => 100000.00,
            'note' => 'Pembelian Banner',
        ]);

        Lapkeu::create([
            'masjid_id' => 1, // Pastikan masjid_id ini sesuai dengan data masjid yang ada
            'tanggal' => '2023-05-30',
            'jumlah' => 15000.00,
            'note' => 'Pembelian Air Mineral',
        ]);

        Lapkeu::create([
            'masjid_id' => 1, // Pastikan masjid_id ini sesuai dengan data masjid yang ada
            'tanggal' => '2023-04-25',
            'jumlah' => 150000.00,
            'note' => 'Amplop Ustad',
        ]);
    }
}
