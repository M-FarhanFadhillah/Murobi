<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'email_verified_at' => now(),
            'password' => Hash::make('123'), // Salt dan bcrypt password
            'no_hp' => '081234567890',
            'profil_pict' => null, // Dibiarkan null
            'is_admin' => true, // Nilai eksplisit
            'status' => 1, // Nilai eksplisit
            'remember_token' => Str::random(10),
        ]);

        User::create([
            'name' => 'Ahmad',
            'email' => 'ahmad@example.com',
            'email_verified_at' => null, // Dibiarkan null
            'password' => Hash::make('Ahmad'), // Salt dan bcrypt password
            'no_hp' => '081298765432',
            'profil_pict' => null, // Dibiarkan null
            'is_admin' => false, // Nilai default
            'status' => 0, // Nilai default
            'remember_token' => Str::random(10),
        ]);

        User::create([
            'name' => 'Brenk',
            'email' => 'brenk@example.com',
            'email_verified_at' => null, // Dibiarkan null
            'password' => Hash::make('brenk'), // Salt dan bcrypt password
            'no_hp' => '085228335432',
            'profil_pict' => null, // Dibiarkan null
            'is_admin' => false, // Nilai default
            'status' => 0, // Nilai default
            'remember_token' => Str::random(10),
        ]);

        User::create([
            'name' => 'Fadil',
            'email' => 'fadil@example.com',
            'email_verified_at' => null, // Dibiarkan null
            'password' => Hash::make('fadil'), // Salt dan bcrypt password
            'no_hp' => '085219455432',
            'profil_pict' => null, // Dibiarkan null
            'is_admin' => false, // Nilai default
            'status' => 0, // Nilai default
            'remember_token' => Str::random(10),
        ]);
    }
}
