<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('data_ziswafs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users');
            $table->foreignId('masjid_id')->constrained('masjids');
            $table->foreignId('jenis_ziswaf_id')->constrained('jenis_ziswafs');
            $table->decimal('jumlah_uang', 20, 2)->nullable();
            $table->string('nama_barang')->nullable();
            $table->date('tanggal');
            $table->string('nama_ziswaf')->nullable();
            $table->string('note')->nullable();
            $table->string('status')->default('pending');
            $table->string('snap_token')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('data_ziswafs');
    }
};
